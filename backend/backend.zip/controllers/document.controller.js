const { Op } = require('sequelize');
const { Document, Customer, DocumentType } = require('../models');
const { validationResult } = require('express-validator');

/**
 * Get all documents with pagination, filters and joined customer
 */
exports.getDocuments = async (req, res) => {
  let { page = 1, limit = 10, customer_id, type, expiry_status } = req.query;
  limit = Math.min(parseInt(limit), 100);
  const offset = (page - 1) * limit;

  const where = {};
  if (customer_id) where.customer_id = customer_id;
  if (type) where.type = type;

  // Set up date boundaries for expiry_status filters
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const next7Days = new Date(today);
  next7Days.setDate(today.getDate() + 7);

  const next14Days = new Date(today);
  next14Days.setDate(today.getDate() + 14);

  const next30Days = new Date(today);
  next30Days.setDate(today.getDate() + 30);

  if (expiry_status === 'expired') {
    where.expiry_date = { [Op.lt]: today };
  } else if (expiry_status === 'critical') {
    where.expiry_date = { [Op.gte]: today, [Op.lte]: next7Days };
  } else if (expiry_status === 'warning') {
    where.expiry_date = { [Op.gt]: next7Days, [Op.lte]: next14Days };
  } else if (expiry_status === 'due_soon') {
    where.expiry_date = { [Op.gt]: next14Days, [Op.lte]: next30Days };
  } else if (expiry_status === 'active') {
    where.expiry_date = { [Op.gt]: next30Days };
  }

  try {
    const { count, rows } = await Document.findAndCountAll({
      where,
      include: [
        {
          model: Customer,
          attributes: ['name', 'phone_whatsapp']
        },
        {
          model: DocumentType,
          attributes: ['name']
        }
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['expiry_date', 'ASC']]
    });

    res.json({
      success: true,
      data: rows,
      meta: {
        total: count,
        page: parseInt(page),
        last_page: Math.ceil(count / limit)
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching documents.' });
  }
};

/**
 * Get single document by ID
 */
exports.getDocumentById = async (req, res) => {
  try {
    const document = await Document.findByPk(req.params.id, {
      include: [
        {
          model: Customer,
          attributes: ['name', 'phone_whatsapp']
        },
        {
          model: DocumentType,
          attributes: ['id', 'name']
        }
      ]
    });
    if (!document) {
      return res.status(404).json({ success: false, message: 'Document not found.' });
    }
    res.json({ success: true, data: document });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching document.' });
  }
};

/**
 * Get expiring documents grouped by urgency
 */
exports.getExpiringDocuments = async (req, res) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const next7Days = new Date(today);
  next7Days.setDate(today.getDate() + 7);

  const next14Days = new Date(today);
  next14Days.setDate(today.getDate() + 14);

  const next30Days = new Date(today);
  next30Days.setDate(today.getDate() + 30);

  try {
    // We fetch all documents. In reality we might want to let the DB do the grouping, 
    // but the prompt specifies 4 arrays. It's often easiest to fetch all expiring within 
    // 30 days and those already expired, then bucket in JS.
    const documents = await Document.findAll({
      include: [
        { model: Customer, attributes: ['name', 'phone_whatsapp'] },
        { model: DocumentType, attributes: ['name'] }
      ],
      order: [['expiry_date', 'ASC']]
    });

    const grouped = {
      expired: [], // Optional addition for completeness based on kanban
      critical: [],
      warning: [],
      month: [],
      safe: []
    };

    documents.forEach(doc => {
      const expiry = new Date(doc.expiry_date);
      if (expiry < today) {
        grouped.expired.push(doc);
      } else if (expiry <= next7Days) {
        grouped.critical.push(doc);
      } else if (expiry <= next14Days) {
        grouped.warning.push(doc);
      } else if (expiry <= next30Days) {
        grouped.month.push(doc);
      } else {
        grouped.safe.push(doc);
      }
    });

    res.json({ success: true, data: grouped });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching expiring documents.' });
  }
};

/**
 * Create a new document
 */
const fs = require('fs');
const path = require('path');

exports.createDocument = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const data = { ...req.body };
    if (req.file) {
      data.file_path = `/uploads/documents/${req.file.filename}`;
    }

    const document = await Document.create(data);
    // Fetch with customer to return a completely populated object
    const populated = await Document.findByPk(document.id, {
      include: [
        { model: Customer, attributes: ['name', 'phone_whatsapp'] },
        { model: DocumentType, attributes: ['name'] }
      ]
    });
    res.status(201).json({ success: true, data: populated });
  } catch (err) {
    console.error('Create Document Error:', err);
    res.status(500).json({ success: false, message: 'Error creating document.' });
  }
};

/**
 * Update an existing document
 */
exports.updateDocument = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    let document = await Document.findByPk(req.params.id);
    if (!document) {
      return res.status(404).json({ success: false, message: 'Document not found.' });
    }

    const data = { ...req.body };
    if (req.file) {
      // Delete old file if exists
      if (document.file_path) {
        const oldPath = path.join(__dirname, '..', document.file_path);
        if (fs.existsSync(oldPath)) {
          fs.unlinkSync(oldPath);
        }
      }
      data.file_path = `/uploads/documents/${req.file.filename}`;
    }

    await document.update(data);
    
    // Fetch populated
    document = await Document.findByPk(req.params.id, {
      include: [
        { model: Customer, attributes: ['name', 'phone_whatsapp'] },
        { model: DocumentType, attributes: ['name'] }
      ]
    });

    res.json({ success: true, data: document });
  } catch (err) {
    console.error('Update Document Error:', err);
    res.status(500).json({ success: false, message: 'Error updating document.' });
  }
};

/**
 * Delete a document
 */
exports.deleteDocument = async (req, res) => {
  try {
    const document = await Document.findByPk(req.params.id);
    if (!document) {
      return res.status(404).json({ success: false, message: 'Document not found.' });
    }

    // Delete file if exists
    if (document.file_path) {
      const filePath = path.join(__dirname, '..', document.file_path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    await document.destroy();
    res.json({ success: true, message: 'Document deleted successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error deleting document.' });
  }
};
