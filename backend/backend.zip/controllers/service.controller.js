const { ServiceType, ServiceOrder, Customer, Invoice, InvoiceItem, sequelize } = require('../models/index.js');
const { Op } = require('sequelize');

/**
 * SERVICE TYPES (Catalog)
 */
exports.getServiceTypes = async (req, res, next) => {
  try {
    let { is_active, page = 1, limit = 10, search = '' } = req.query;
    limit = Math.min(parseInt(limit), 100);
    const offset = (page - 1) * limit;

    const where = {};
    if (is_active !== undefined) where.is_active = is_active === 'true';
    if (search) where.name = { [Op.like]: `%${search}%` };

    const { count, rows } = await ServiceType.findAndCountAll({ 
      where, 
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['name', 'ASC']] 
    });

    res.json({ 
      success: true, 
      data: rows,
      meta: {
        total: count,
        page: parseInt(page),
        last_page: Math.ceil(count / limit)
      }
    });
  } catch (err) {
    next(err);
  }
};

exports.createServiceType = async (req, res, next) => {
  try {
    const type = await ServiceType.create(req.body);
    res.status(201).json({ success: true, data: type });
  } catch (err) {
    next(err);
  }
};

exports.updateServiceType = async (req, res, next) => {
  try {
    const type = await ServiceType.findByPk(req.params.id);
    if (!type) return res.status(404).json({ success: false, message: 'Service type not found' });

    await type.update(req.body);
    res.json({ success: true, data: type });
  } catch (err) {
    next(err);
  }
};

exports.deleteServiceType = async (req, res, next) => {
  try {
    const type = await ServiceType.findByPk(req.params.id);
    if (!type) return res.status(404).json({ success: false, message: 'Service type not found' });

    // Check if used in orders
    const count = await ServiceOrder.count({ where: { service_type_id: type.id } });
    if (count > 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Cannot delete service type that is linked to existing orders. Deactivate it instead.' 
      });
    }

    await type.destroy();
    res.json({ success: true, message: 'Service type deleted' });
  } catch (err) {
    next(err);
  }
};

/**
 * SERVICE ORDERS (Workflow)
 */
exports.getServiceOrders = async (req, res, next) => {
  try {
    let { status, customer_id, page = 1, limit = 10 } = req.query;
    limit = Math.min(parseInt(limit), 100);
    const offset = (page - 1) * limit;

    const where = {};
    if (status) where.status = status;
    if (customer_id) where.customer_id = customer_id;

    const { count, rows } = await ServiceOrder.findAndCountAll({
      where,
      include: [
        { model: Customer, attributes: ['id', 'name', 'phone_whatsapp'] },
        { model: ServiceType, attributes: ['id', 'name', 'sell_price', 'cost_price'] }
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['created_at', 'DESC']]
    });

    res.json({ 
      success: true, 
      data: rows,
      meta: {
        total: count,
        page: parseInt(page),
        last_page: Math.ceil(count / limit)
      }
    });
  } catch (err) {
    next(err);
  }
};

exports.createServiceOrder = async (req, res, next) => {
  try {
    const order = await ServiceOrder.create(req.body);
    const fullOrder = await ServiceOrder.findByPk(order.id, {
      include: [
        { model: Customer, attributes: ['id', 'name', 'phone_whatsapp'] },
        { model: ServiceType, attributes: ['id', 'name', 'sell_price', 'cost_price'] }
      ]
    });
    res.status(201).json({ success: true, data: fullOrder });
  } catch (err) {
    next(err);
  }
};

exports.updateServiceOrderStatus = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  try {
    const { status } = req.body;
    const order = await ServiceOrder.findByPk(req.params.id, {
      include: [ServiceType, Customer],
      transaction
    });

    if (!order) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    const oldStatus = order.status;
    const updates = { status };

    // Transition Logic
    if (oldStatus === 'Pending' && status === 'InProgress') {
      updates.started_at = new Date();
    } else if (oldStatus === 'InProgress' && status === 'Completed') {
      updates.completed_at = new Date();
      
      // AUTO-GENERATE INVOICE
      const invoiceNumber = await generateInvoiceNumber(transaction);
      const invoice = await Invoice.create({
        invoice_number: invoiceNumber,
        customer_id: order.customer_id,
        service_order_id: order.id,
        subtotal: order.ServiceType.sell_price,
        total: order.ServiceType.sell_price,
        cost_total: order.ServiceType.cost_price,
        status: 'Draft',
        notes: `Auto-generated from service order #${order.id}`
      }, { transaction });

      await InvoiceItem.create({
        invoice_id: invoice.id,
        description: order.ServiceType.name,
        quantity: 1,
        unit_price: order.ServiceType.sell_price,
        cost_price: order.ServiceType.cost_price,
        total: order.ServiceType.sell_price
      }, { transaction });
    } 
    // REVERSAL LOGIC
    else if (oldStatus === 'Completed' && status === 'InProgress') {
      updates.completed_at = null;
      
      // Find linked invoice
      const invoice = await Invoice.findOne({ 
        where: { service_order_id: order.id, status: 'Draft' },
        transaction 
      });
      
      if (invoice) {
        await InvoiceItem.destroy({ where: { invoice_id: invoice.id }, transaction });
        await invoice.destroy({ transaction });
      } else {
        // If invoice is NOT draft (sent/paid), block reversal
        const persistentInvoice = await Invoice.findOne({
          where: { service_order_id: order.id },
          transaction
        });
        if (persistentInvoice) {
          await transaction.rollback();
          return res.status(400).json({ 
            success: false, 
            message: 'Cannot revert status. Invoice is already processed (Sent/Paid).' 
          });
        }
      }
    }

    await order.update(updates, { transaction });
    await transaction.commit();

    const updatedOrder = await ServiceOrder.findByPk(order.id, {
      include: [
        { model: Customer, attributes: ['id', 'name', 'phone_whatsapp'] },
        { model: ServiceType, attributes: ['id', 'name', 'sell_price', 'cost_price'] }
      ]
    });

    res.json({ 
      success: true, 
      data: updatedOrder,
      message: status === 'Completed' ? 'Order completed and Draft Invoice generated' : 'Status updated'
    });
  } catch (err) {
    await transaction.rollback();
    next(err);
  }
};

exports.deleteServiceOrder = async (req, res, next) => {
  try {
    const order = await ServiceOrder.findByPk(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    if (!['Pending', 'Cancelled'].includes(order.status)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Only Pending or Cancelled orders can be deleted.' 
      });
    }

    await order.destroy();
    res.json({ success: true, message: 'Order deleted' });
  } catch (err) {
    next(err);
  }
};

// Helper to generate Invoice Number (INV-YYYY-XXXX)
async function generateInvoiceNumber(transaction) {
  const year = new Date().getFullYear();
  const lastInvoice = await Invoice.findOne({
    where: {
      invoice_number: { [Op.like]: `INV-${year}-%` }
    },
    order: [['invoice_number', 'DESC']],
    transaction
  });

  let nextNum = 1;
  if (lastInvoice) {
    const parts = lastInvoice.invoice_number.split('-');
    nextNum = parseInt(parts[2]) + 1;
  }
  
  return `INV-${year}-${nextNum.toString().padStart(4, '0')}`;
}
