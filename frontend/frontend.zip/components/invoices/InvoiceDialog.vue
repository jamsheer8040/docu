<template>
  <v-card class="pa-4 rounded-xl">
    <v-card-title class="pa-6 d-flex align-center">
      <div class="text-h5 font-weight-bold">
        <v-icon icon="mdi-receipt-text-plus-outline" class="mr-3" color="primary"></v-icon>
        {{ isEdit ? 'Edit Invoice' : 'Create Manual Invoice' }}
      </div>
      <v-spacer></v-spacer>
      <v-btn icon="mdi-close" variant="text" @click="$emit('cancel')"></v-btn>
    </v-card-title>

    <v-card-text>
      <v-form ref="form" v-model="valid">
        <v-row>
          <!-- Customer Selection -->
          <v-col cols="12" md="6">
            <v-autocomplete
              v-model="state.customer_id"
              :items="customers"
              item-title="name"
              item-value="id"
              label="Customer *"
              placeholder="Search by name"
              :rules="[v => !!v || 'Customer is required']"
              variant="outlined"
              density="comfortable"
              :loading="loadingCustomers"
            ></v-autocomplete>
          </v-col>

          <!-- Date Selection (Manual Simple Input) -->
          <v-col cols="12" md="6">
            <v-text-field
              v-model="state.due_date"
              label="Due Date"
              type="date"
              variant="outlined"
              density="comfortable"
            ></v-text-field>
          </v-col>
        </v-row>

        <v-divider class="my-6"></v-divider>

        <!-- Itemized Table Header -->
        <div class="d-flex align-center mb-4 px-2">
          <div class="text-subtitle-1 font-weight-bold">Invoice Items</div>
          <v-spacer></v-spacer>
          <v-btn
            prepend-icon="mdi-plus"
            variant="tonal"
            color="primary"
            size="small"
            @click="addItem"
          >
            Add Item
          </v-btn>
        </div>

        <div v-for="(item, index) in state.items" :key="index" class="item-row mb-4 pa-4 border rounded-xl bg-surface-variant-light">
          <v-row dense align="center">
            <v-col cols="12" md="6">
              <v-text-field
                v-model="item.description"
                label="Description *"
                placeholder="e.g., Partner Visa Stamping"
                :rules="[v => !!v || 'Required']"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="3" md="1">
              <v-text-field
                v-model.number="item.quantity"
                label="Qty"
                type="number"
                min="1"
                hide-details="auto"
                @input="calculateRow(index)"
              ></v-text-field>
            </v-col>
            <v-col cols="4" md="2">
              <v-text-field
                v-model.number="item.unit_price"
                label="Price"
                prefix="AED"
                type="number"
                hide-details="auto"
                @input="calculateRow(index)"
              ></v-text-field>
            </v-col>
            <v-col cols="4" md="2">
              <div class="text-right pt-4 px-2">
                 <div class="text-caption opacity-60">Total</div>
                 <div class="font-weight-bold text-subtitle-1">AED {{ item.total.toFixed(2) }}</div>
              </div>
            </v-col>
            <v-col cols="1" class="text-right">
              <v-btn
                v-if="state.items.length > 1"
                icon="mdi-minus-circle-outline"
                variant="text"
                color="error"
                size="small"
                @click="removeItem(index)"
              ></v-btn>
            </v-col>
          </v-row>
        </div>

        <!-- Totals & Notes Section -->
        <v-row class="mt-4">
          <v-col cols="12" md="7">
            <v-textarea
              v-model="state.notes"
              label="Internal / Customer Notes"
              rows="3"
              placeholder="Terms and conditions, payment info, etc."
              variant="outlined"
              class="mb-4"
            ></v-textarea>
          </v-col>
          <v-col cols="12" md="5" class="bg-grey-lighten-5 rounded-xl pa-6 border">
            <div class="d-flex justify-space-between mb-4">
              <span class="opacity-70">Subtotal</span>
              <span class="font-weight-bold">AED {{ totals.subtotal.toFixed(2) }}</span>
            </div>
            
            <div class="d-flex align-center mb-4">
              <span class="opacity-70">Discount</span>
              <v-spacer></v-spacer>
              <v-text-field
                v-model.number="state.discount"
                prefix="AED"
                type="number"
                density="compact"
                hide-details
                style="max-width: 100px;"
                class="bg-white ml-2"
              ></v-text-field>
            </div>

            <div class="d-flex align-center mb-6">
              <span class="opacity-70">Tax (e.g. VAT 5%)</span>
              <v-spacer></v-spacer>
              <v-text-field
                v-model.number="state.tax"
                prefix="AED"
                type="number"
                density="compact"
                hide-details
                style="max-width: 100px;"
                class="bg-white ml-2"
              ></v-text-field>
            </div>

            <v-divider class="mb-4"></v-divider>

            <div class="d-flex justify-space-between align-center">
              <span class="text-h6 font-weight-bold">Grand Total</span>
              <span class="text-h5 font-weight-bold text-primary">AED {{ totals.total.toFixed(2) }}</span>
            </div>
          </v-col>
        </v-row>
      </v-form>
    </v-card-text>

    <v-card-actions class="pa-6">
      <v-spacer></v-spacer>
      <v-btn variant="text" size="large" @click="$emit('cancel')">Discard Changes</v-btn>
      <v-btn
        color="primary"
        variant="flat"
        size="large"
        class="px-10"
        :loading="invoiceStore.loading"
        @click="save"
      >
        Save Invoice
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script setup>
import { reactive, ref, computed, onMounted } from 'vue';
import { useInvoiceStore } from '~/stores/invoices';

const props = defineProps({
  invoice: Object, // for editing
});

const emit = defineEmits(['save', 'cancel']);

const invoiceStore = useInvoiceStore();
const customers = ref([]);
const loadingCustomers = ref(false);
const valid = ref(false);
const form = ref(null);

const isEdit = !!props.invoice;

const state = reactive({
  customer_id: null,
  due_date: new Date().toISOString().substring(0, 10),
  notes: '',
  discount: 0,
  tax: 0,
  items: [
    { description: '', quantity: 1, unit_price: 0, total: 0 }
  ]
});

// Calculate Totals Reactively
const totals = computed(() => {
    const subtotal = state.items.reduce((acc, item) => {
        const qty = parseFloat(item.quantity) || 0;
        const price = parseFloat(item.unit_price) || 0;
        return acc + (qty * price);
    }, 0);
    
    const discount = parseFloat(state.discount) || 0;
    const tax = parseFloat(state.tax) || 0;
    
    // AED -92k bug fix: total cannot be negative
    const total = Math.max(0, subtotal - discount + tax);
    
    return { 
        subtotal: parseFloat(subtotal.toFixed(2)), 
        total: parseFloat(total.toFixed(2)) 
    };
});

const fetchCustomers = async () => {
  loadingCustomers.value = true;
  try {
    const { $api } = useNuxtApp();
    const response = await $api.get('/customers', { params: { limit: 1000, is_active: 'true' } });
    if (response.data?.success) {
      customers.value = response.data.data;
    }
  } catch (err) {
    console.error('Failed to fetch customers', err);
  } finally {
    loadingCustomers.value = false;
  }
};

onMounted(() => {
  fetchCustomers();
  if (isEdit) {
      Object.assign(state, {
          customer_id: props.invoice.customer_id,
          due_date: props.invoice.due_date,
          notes: props.invoice.notes || '',
          discount: parseFloat(props.invoice.discount) || 0,
          tax: parseFloat(props.invoice.tax) || 0,
          items: props.invoice.InvoiceItems.map(i => {
              const qty = parseFloat(i.quantity);
              const price = parseFloat(i.unit_price);
              return {
                  description: i.description,
                  quantity: qty,
                  unit_price: price,
                  total: qty * price
              };
          })
      });
  }
});

const addItem = () => {
    state.items.push({ description: '', quantity: 1, unit_price: 0, total: 0 });
};

const removeItem = (index) => {
    state.items.splice(index, 1);
};

const calculateRow = (index) => {
    const item = state.items[index];
    item.total = parseFloat(item.quantity || 0) * parseFloat(item.unit_price || 0);
};

const save = async () => {
    const { valid } = await form.value.validate();
    if (!valid) return;

    try {
        if (isEdit) {
            await invoiceStore.updateInvoice(props.invoice.id, state); 
        } else {
            await invoiceStore.createInvoice(state);
        }
        emit('save');
    } catch (err) {
        alert(err.message || 'Operation failed');
    }
};
</script>

<style scoped>
.bg-surface-variant-light {
    background-color: #F8F9FA;
}
.item-row {
    transition: all 0.2s;
}
.item-row:hover {
    border-color: #0B57D0 !important;
    background-color: #FFFFFF;
}
</style>
