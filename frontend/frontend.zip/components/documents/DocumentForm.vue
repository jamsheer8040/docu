<template>
  <v-form @submit.prevent="submitForm">
    <v-card>
      <v-card-title class="pa-6 d-flex align-center">
        <div class="text-h6 font-weight-bold">
          <v-icon icon="mdi-file-edit-outline" class="mr-2" color="primary"></v-icon>
          {{ isEdit ? 'Edit Document' : 'Add New Document' }}
        </div>
        <v-spacer></v-spacer>
        <v-btn icon="mdi-close" variant="text" size="small" @click="$emit('cancel')"></v-btn>
      </v-card-title>

      <v-card-text class="pt-4">
        <!-- Customer Selection -->
        <v-autocomplete
          v-model="formData.customer_id"
          :items="customers"
          item-title="name"
          item-value="id"
          label="Customer *"
          placeholder="Search by name"
          :error-messages="v$.customer_id.$errors.map(e => e.$message)"
          @blur="v$.customer_id.$touch()"
          class="mb-2"
          :loading="loadingCustomers"
        ></v-autocomplete>

        <!-- Document Type -->
        <v-select
          v-model="formData.document_type_id"
          :items="documentTypes"
          item-title="name"
          item-value="id"
          label="Document Type *"
          :error-messages="v$.document_type_id.$errors.map(e => e.$message)"
          @blur="v$.document_type_id.$touch()"
          class="mb-2"
          :loading="loadingTypes"
        ></v-select>

        <!-- Document Number -->
        <v-text-field
          v-model="formData.doc_number"
          label="Document Number"
          :error-messages="v$.doc_number.$errors.map(e => e.$message)"
          @blur="v$.doc_number.$touch()"
          class="mb-2"
        ></v-text-field>

        <v-row>
          <!-- Issue Date -->
          <v-col cols="12" md="6">
            <v-text-field
              v-model="formData.issue_date"
              label="Issue Date"
              type="date"
              :error-messages="v$.issue_date.$errors.map(e => e.$message)"
              @blur="v$.issue_date.$touch()"
              class="mb-2"
            ></v-text-field>
          </v-col>

          <!-- Expiry Date -->
          <v-col cols="12" md="6">
            <v-text-field
              v-model="formData.expiry_date"
              label="Expiry Date *"
              type="date"
              :error-messages="v$.expiry_date.$errors.map(e => e.$message)"
              @blur="v$.expiry_date.$touch()"
              class="mb-2"
              :hint="expiryHint"
              persistent-hint
            ></v-text-field>
          </v-col>
        </v-row>

        <!-- File Attachment -->
        <div class="mb-4">
          <div class="text-subtitle-2 mb-1 font-weight-bold d-flex align-center">
            <v-icon icon="mdi-paperclip" size="small" class="mr-2" color="primary"></v-icon>
            Document Attachment (PDF or Image)
          </div>
          <v-file-input
            v-model="file"
            label="Upload Document"
            variant="outlined"
            density="compact"
            prepend-icon=""
            prepend-inner-icon="mdi-upload"
            accept=".pdf,image/*"
            show-size
            clearable
            :hint="props.document?.file_path ? 'Existing file found. Upload new to replace.' : 'Max size: 10MB'"
            persistent-hint
            rounded="lg"
          >
            <template v-slot:append-inner v-if="props.document?.file_path">
              <v-tooltip text="View Current File" location="top">
                <template v-slot:activator="{ props: tooltipProps }">
                  <v-btn
                    v-bind="tooltipProps"
                    icon="mdi-eye-outline"
                    size="x-small"
                    variant="tonal"
                    color="primary"
                    :href="config.public.apiBase + props.document.file_path"
                    target="_blank"
                  ></v-btn>
                </template>
              </v-tooltip>
            </template>
          </v-file-input>
        </div>

        <!-- Notes -->
        <v-textarea
          v-model="formData.notes"
          label="Notes / Remarks"
          :error-messages="v$.notes.$errors.map(e => e.$message)"
          @blur="v$.notes.$touch()"
          rows="3"
          variant="outlined"
          rounded="lg"
        ></v-textarea>
      </v-card-text>

      <v-card-actions class="pa-6 pt-0">
        <v-spacer></v-spacer>
        <v-btn variant="text" color="grey-darken-1" rounded="lg" @click="$emit('cancel')">Cancel</v-btn>
        <v-btn 
          type="submit" 
          color="primary" 
          variant="flat"
          class="px-8 font-weight-bold"
          rounded="lg"
          :loading="loading" 
          :disabled="!v$.$anyDirty && isEdit && !file"
        >
          {{ isEdit ? 'Save Changes' : 'Create Document' }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-form>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength } from '@vuelidate/validators';

const props = defineProps({
  document: {
    type: Object,
    default: null
  },
  loading: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['save', 'cancel']);
const config = useRuntimeConfig();

const isEdit = computed(() => !!props.document);
const documentTypes = ref([]);
const customers = ref([]);
const loadingCustomers = ref(false);
const loadingTypes = ref(false);
const file = ref(null);

const formData = reactive({
  customer_id: null,
  document_type_id: null,
  type: null, // Keep for legacy
  doc_number: '',
  issue_date: '',
  expiry_date: '',
  notes: ''
});

// Custom validators
const isAfterIssueDate = (value, vm) => {
  if (!value || !vm.issue_date) return true;
  return new Date(value) > new Date(vm.issue_date);
};

const v$ = useVuelidate({
  customer_id: { required },
  document_type_id: { required },
  doc_number: { maxLength: maxLength(100) },
  issue_date: {},
  expiry_date: { 
    required,
    isAfterIssueDate: {
      $validator: isAfterIssueDate,
      $message: 'Expiry date must be after issue date'
    }
  },
  notes: { maxLength: maxLength(500) }
}, formData);

const expiryHint = computed(() => {
  if (!formData.expiry_date || v$.value.expiry_date.$invalid) return '';
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(formData.expiry_date);
  const diff = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
  
  if (diff < 0) return `Alert: Expired ${Math.abs(diff)} days ago`;
  if (diff === 0) return 'Alert: Expires today!';
  return `Expires in ${diff} days`;
});

const fetchCustomers = async () => {
  loadingCustomers.value = true;
  try {
    const { $api } = useNuxtApp();
    const response = await $api.get('/customers?limit=1000&is_active=true');
    if (response.data?.success) {
      customers.value = response.data.data;
    }
  } catch (err) {
    console.error('Failed to fetch customers for document form', err);
  } finally {
    loadingCustomers.value = false;
  }
};

const fetchDocTypes = async () => {
  loadingTypes.value = true;
  try {
    const { $api } = useNuxtApp();
    const res = await $api.get('/document-types');
    if (res.data?.success) {
      documentTypes.value = res.data.data;
      
      // If editing and we have a legacy type but no document_type_id, try to auto-match
      if (props.document && !props.document.document_type_id && props.document.type) {
          const match = documentTypes.value.find(t => t.name.toLowerCase() === props.document.type.toLowerCase());
          if (match) formData.document_type_id = match.id;
      }
    }
  } catch (err) {
    console.error('Failed to fetch doc types for document form', err);
    // Fallback if API fails
    documentTypes.value = [
      { id: 1, name: 'Visa' },
      { id: 2, name: 'Passport' },
      { id: 3, name: 'TradeLicense' },
      { id: 4, name: 'EmiratesID' }
    ];
  } finally {
    loadingTypes.value = false;
  }
};


onMounted(() => {
  fetchCustomers();
  fetchDocTypes();
  if (props.document) {
    Object.assign(formData, {
      ...props.document,
      // Ensure dates are correctly formatted for input type="date"
      issue_date: props.document.issue_date ? props.document.issue_date.split('T')[0] : '',
      expiry_date: props.document.expiry_date ? props.document.expiry_date.split('T')[0] : ''
    });
  }
});

const submitForm = async () => {
  const isValid = await v$.value.$validate();
  if (!isValid) return;
  
  const data = new FormData();
  // Append all form fields
  Object.keys(formData).forEach(key => {
    if (formData[key] !== null && formData[key] !== undefined) {
      data.append(key, formData[key]);
    } else if (key === 'issue_date') {
        // Handle explicit null for date
        // Actually FormData sends strings, so 'null' string is bad. 
        // We just don't append it or append empty if backend handles it.
    }
  });

  if (file.value) {
      const fileToUpload = Array.isArray(file.value) ? file.value[0] : file.value;
      data.append('file', fileToUpload);
  }
  
  emit('save', data);
};
</script>
