<template>
  <v-container fluid class="pa-6">
    <!-- Page Header -->
    <v-row class="mb-6 align-center">
      <v-col cols="12" md="6">
        <h1 class="text-h4 font-weight-bold color-primary">
          <v-icon icon="mdi-cog-outline" class="mr-2" color="primary"></v-icon>
          Service Management
        </h1>
        <p class="text-subtitle-1 text-grey-darken-1">Manage your catalog and track active service workflows</p>
      </v-col>
      <v-col cols="12" md="6" class="d-flex align-center justify-md-end flex-wrap gap-3">
        <v-btn
          v-if="auth.can('services', 'write')"
          color="primary"
          variant="flat"
          prepend-icon="mdi-clipboard-plus-outline"
          rounded="lg"
          elevation="2"
          height="44"
          class="px-6 font-weight-bold"
          @click="openOrderForm()"
        >
          New Service Order
        </v-btn>
      </v-col>
    </v-row>

    <!-- SECTION A: VIEW TOGGLE & FILTERS -->
    <v-card class="mb-6 border pa-2" border variant="flat">
      <div class="d-flex align-center flex-wrap gap-4 px-4">
        <v-tabs v-model="viewMode" color="primary" density="compact" class="rounded-lg">
          <v-tab value="kanban" prepend-icon="mdi-view-column-outline">Kanban Board</v-tab>
          <v-tab value="list" prepend-icon="mdi-format-list-bulleted">List View</v-tab>
        </v-tabs>
        
        <v-spacer></v-spacer>
        
        <v-text-field
          v-model="searchOrders"
          label="Search orders..."
          prepend-inner-icon="mdi-magnify"
          density="compact"
          hide-details
          style="max-width: 250px;"
          variant="outlined"
          rounded="lg"
          class="bg-white"
        ></v-text-field>

        <v-btn 
          icon="mdi-refresh" 
          variant="text" 
          @click="fetchData" 
          :loading="serviceStore.loading"
        ></v-btn>
      </div>
    </v-card>

    <v-window v-model="viewMode">
      <!-- KANBAN VIEW -->
      <v-window-item value="kanban">
        <div class="kanban-container mt-4">
          <v-row class="kanban-row flex-nowrap overflow-x-auto pb-4">
            <!-- PENDING -->
            <v-col class="kanban-col border-r">
              <div class="pa-2 mb-4 bg-surface rounded-xl border d-flex align-center">
                <v-avatar color="grey-lighten-3" size="32" class="mr-3">
                  <span class="text-caption font-weight-bold">1</span>
                </v-avatar>
                <span class="text-subtitle-1 font-weight-bold">Pending ({{ groupedOrders.Pending.length }})</span>
              </div>
              
              <v-slide-y-transition group>
                <v-card
                  v-for="order in groupedOrders.Pending"
                  :key="order.id"
                  class="mb-4 order-card border"
                  border
                >
                  <v-card-text class="pa-4">
                    <div class="d-flex justify-space-between mb-2">
                      <span class="text-caption font-weight-bold text-uppercase opacity-60">ID #{{ order.id }}</span>
                      <v-chip size="x-small" color="secondary" variant="outlined">{{ order.ServiceType?.name }}</v-chip>
                    </div>
                    <div class="text-subtitle-1 font-weight-bold mb-1">{{ order.Customer?.name }}</div>
                    <div v-if="order.notes" class="text-caption text-truncate opacity-70 mb-3">
                      <v-icon size="x-small" icon="mdi-note-outline" class="mr-1"></v-icon>
                      {{ order.notes }}
                    </div>
                    
                    <div class="d-flex justify-space-between align-center mt-2">
                       <v-btn icon="mdi-whatsapp" color="success" size="small" variant="text" @click.stop="openWhatsAppRemind(order)"></v-btn>
                       <v-btn v-if="auth.can('services', 'write')" color="primary" block variant="tonal" class="ml-2" size="small" append-icon="mdi-arrow-right" @click.stop="updateStatus(order, 'InProgress')">Start Workflow</v-btn>
                    </div>
                  </v-card-text>
                </v-card>
              </v-slide-y-transition>
              <div v-if="groupedOrders.Pending.length === 0" class="text-caption text-center py-6 opacity-40">No pending orders</div>
            </v-col>

            <!-- IN PROGRESS -->
            <v-col class="kanban-col border-r">
              <div class="pa-2 mb-4 bg-primary-container rounded-xl border d-flex align-center border-primary">
                <v-avatar color="primary" variant="tonal" size="32" class="mr-3">
                  <span class="text-caption font-weight-bold">2</span>
                </v-avatar>
                <span class="text-subtitle-1 font-weight-bold text-on-primary-container">In Progress ({{ groupedOrders.InProgress.length }})</span>
              </div>
              
              <v-slide-y-transition group>
                <v-card
                  v-for="order in groupedOrders.InProgress"
                  :key="order.id"
                  class="mb-4 order-card border"
                  border
                >
                  <v-card-text class="pa-4">
                    <div class="d-flex justify-space-between mb-2">
                      <span class="text-caption font-weight-bold text-uppercase opacity-60">ID #{{ order.id }}</span>
                      <v-chip size="x-small" color="info" variant="outlined">{{ order.ServiceType?.name }}</v-chip>
                    </div>
                    <div class="text-subtitle-1 font-weight-bold mb-1">{{ order.Customer?.name }}</div>
                    <div class="text-caption mb-3 opacity-70">
                        <v-icon size="x-small" icon="mdi-calendar-play-outline" class="mr-1"></v-icon>
                        Started: {{ formatDate(order.started_at) }}
                    </div>
                    
                    <div class="d-flex gap-2 align-center mt-2">
                       <v-btn icon="mdi-whatsapp" color="success" size="small" variant="text" @click.stop="openWhatsAppRemind(order)"></v-btn>
                       <v-btn v-if="auth.can('services', 'write')" color="success" block variant="flat" size="small" append-icon="mdi-check" @click.stop="confirmOrderCompletion(order)">Complete Service</v-btn>
                    </div>
                  </v-card-text>
                </v-card>
              </v-slide-y-transition>
              <div v-if="groupedOrders.InProgress.length === 0" class="text-caption text-center py-6 opacity-40">No services in progress</div>
            </v-col>

            <!-- COMPLETED -->
            <v-col class="kanban-col border-r">
              <div class="pa-2 mb-4 bg-secondary-container rounded-xl border d-flex align-center border-secondary">
                <v-avatar color="secondary" variant="tonal" size="32" class="mr-3">
                  <span class="text-caption font-weight-bold">3</span>
                </v-avatar>
                <span class="text-subtitle-1 font-weight-bold text-on-secondary-container">Completed ({{ groupedOrders.Completed.length }})</span>
              </div>
              
              <v-slide-y-transition group>
                <v-card
                  v-for="order in groupedOrders.Completed"
                  :key="order.id"
                  class="mb-4 order-card border bg-grey-lighten-5 opacity-80"
                  border
                >
                  <v-card-text class="pa-4">
                    <div class="d-flex justify-space-between mb-2">
                      <span class="text-caption font-weight-bold text-uppercase opacity-60">ID #{{ order.id }}</span>
                      <v-chip size="x-small" color="grey" variant="flat">Invoice Created</v-chip>
                    </div>
                    <div class="text-subtitle-1 font-weight-bold mb-1 opacity-60">{{ order.Customer?.name }}</div>
                    <div class="text-caption mb-3">
                        <v-icon size="x-small" icon="mdi-check-all" color="success" class="mr-1"></v-icon>
                        {{ order.ServiceType?.name }}
                    </div>
                    
                    <div class="d-flex justify-space-between align-center mt-2 border-t pt-2 mt-auto">
                        <v-btn v-if="auth.can('services', 'write')" color="grey-darken-1" variant="text" size="x-small" prepend-icon="mdi-undo" @click.stop="revertOrder(order)">Revert to In Progress</v-btn>
                        <v-btn color="primary" variant="text" size="x-small" append-icon="mdi-arrow-right" to="/invoices">View Invoices</v-btn>
                    </div>
                  </v-card-text>
                </v-card>
              </v-slide-y-transition>
              <div v-if="groupedOrders.Completed.length === 0" class="text-caption text-center py-6 opacity-40">No completed orders today</div>
            </v-col>

            <!-- CANCELLED -->
            <v-col class="kanban-col">
              <div class="pa-2 mb-4 bg-error-container rounded-xl border d-flex align-center border-error">
                <v-avatar color="error" variant="tonal" size="32" class="mr-3">
                  <v-icon icon="mdi-cancel" size="small"></v-icon>
                </v-avatar>
                <span class="text-subtitle-1 font-weight-bold text-on-error-container">Cancelled ({{ groupedOrders.Cancelled.length }})</span>
              </div>
              
              <v-slide-y-transition group>
                <v-card
                  v-for="order in groupedOrders.Cancelled"
                  :key="order.id"
                  class="mb-4 order-card border bg-grey-lighten-5 opacity-60 grayscale"
                  border
                >
                  <v-card-text class="pa-4">
                    <div class="d-flex justify-space-between mb-2">
                      <span class="text-caption font-weight-bold text-uppercase opacity-60">ID #{{ order.id }}</span>
                      <v-chip size="x-small" color="error" variant="flat">Cancelled</v-chip>
                    </div>
                    <div class="text-subtitle-1 font-weight-bold mb-1">{{ order.Customer?.name }}</div>
                    <div class="text-caption mb-3">
                        {{ order.ServiceType?.name }}
                    </div>
                    
                    <div class="d-flex justify-end align-center mt-2 border-t pt-2">
                        <v-btn v-if="auth.can('services', 'write')" color="primary" variant="text" size="x-small" prepend-icon="mdi-restore" @click.stop="updateStatus(order, 'Pending')">Restore to Pending</v-btn>
                    </div>
                  </v-card-text>
                </v-card>
              </v-slide-y-transition>
              <div v-if="groupedOrders.Cancelled.length === 0" class="text-caption text-center py-6 opacity-40">No cancelled orders</div>
            </v-col>
          </v-row>
        </div>
      </v-window-item>

      <!-- LIST VIEW -->
      <v-window-item value="list">
        <v-card class="border mt-4" border>
          <v-data-table
            :headers="orderHeaders"
            :items="filteredOrders"
            :loading="serviceStore.loading"
            hover
          >
            <!-- Service Column -->
            <template v-slot:item.ServiceType="{ item }">
              <div class="font-weight-bold">{{ item.ServiceType?.name }}</div>
              <div class="text-caption text-grey">{{ item.ServiceType?.category }}</div>
            </template>

            <!-- Customer Column -->
            <template v-slot:item.Customer="{ item }">
              <div class="font-weight-bold">{{ item.Customer?.name }}</div>
              <div class="text-caption text-grey">{{ item.Customer?.phone_whatsapp }}</div>
            </template>

            <!-- Date Column -->
            <template v-slot:item.created_at="{ item }">
               {{ formatDate(item.created_at) }}
            </template>

            <!-- Profit Column -->
            <template v-slot:item.profit="{ item }">
              <span class="text-success font-weight-bold">
                AED {{ (item.ServiceType?.sell_price - item.ServiceType?.cost_price).toFixed(2) }}
              </span>
            </template>

            <!-- Status Column -->
            <template v-slot:item.status="{ item }">
              <v-select
                v-model="item.status"
                :items="['Pending', 'InProgress', 'Completed', 'Cancelled']"
                density="compact"
                hide-details
                variant="outlined"
                rounded="lg"
                style="width: 150px"
                :color="getStatusColor(item.status)"
                @update:model-value="(val) => updateStatus(item, val)"
                v-if="auth.can('services', 'write')"
              >
                <template v-slot:selection="{ item: statusItem }">
                  <v-chip :color="getStatusColor(statusItem.title)" size="x-small" label class="font-weight-bold text-uppercase">
                    {{ statusItem.title }}
                  </v-chip>
                </template>
              </v-select>
              <v-chip v-else :color="getStatusColor(item.status)" size="x-small" label class="font-weight-bold text-uppercase">
                {{ item.status }}
              </v-chip>
            </template>

            <!-- Actions -->
            <template v-slot:item.actions="{ item }">
              <v-btn icon="mdi-whatsapp" variant="text" size="small" color="success" @click="openWhatsAppRemind(item)"></v-btn>
              <v-btn v-if="auth.can('services', 'delete')" icon="mdi-delete-outline" variant="text" size="small" color="error" @click="confirmDeleteOrder(item)"></v-btn>
            </template>
          </v-data-table>
        </v-card>
      </v-window-item>
    </v-window>

    <!-- DIALOGS -->


    <!-- Service Order Form Dialog -->
    <v-dialog v-model="orderDialog" max-width="600px" persistent>
      <ServiceOrderForm
        v-if="orderDialog"
        :service-types="activeServiceTypes"
        :loading="serviceStore.loading"
        @save="createOrder"
        @cancel="orderDialog = false"
      />
    </v-dialog>

    <!-- Global Confirm Dialog -->
    <ConfirmDialog
      v-model="confirmDialog.show"
      :title="confirmDialog.title"
      :message="confirmDialog.message"
      :confirm-text="confirmDialog.confirmText"
      color="success"
      icon="mdi-receipt-text-plus"
      :loading="serviceStore.loading"
      @confirm="executeOrderCompletion"
    />

    <!-- Snackbar Notifications -->
    <v-snackbar v-model="snackbar.show" :color="snackbar.color" :timeout="4000">
      {{ snackbar.text }}
      <template v-slot:actions>
        <v-btn variant="text" @click="snackbar.show = false">Close</v-btn>
      </template>
    </v-snackbar>
  </v-container>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue';
import { useServiceStore } from '~/stores/services';
import { useAuthStore } from '~/stores/auth';
import ServiceOrderForm from '~/components/services/ServiceOrderForm.vue';
import ConfirmDialog from '~/components/common/ConfirmDialog.vue';
import { useWhatsApp } from '~/composables/useWhatsApp';

// Stores & State
const serviceStore = useServiceStore();
const auth = useAuthStore();
const { openWhatsApp, MESSAGES } = useWhatsApp();

// Page UI
const viewMode = ref('kanban');
const searchOrders = ref('');
const orderDialog = ref(false);
const selectedOrderForCompletion = ref(null);

const snackbar = reactive({
  show: false,
  text: '',
  color: 'success'
});

const confirmDialog = reactive({
  show: false,
  title: '',
  message: '',
  confirmText: 'Continue'
});

/**
 * ORDERS TABLE CONFIG
 */
const orderHeaders = [
  { title: 'Order ID', key: 'id', width: '100px' },
  { title: 'Created At', key: 'created_at', sortable: true },
  { title: 'Customer', key: 'Customer', sortable: true },
  { title: 'Service', key: 'ServiceType', sortable: true },
  { title: 'Profit', key: 'profit', align: 'end' },
  { title: 'Status', key: 'status', align: 'center', sortable: true },
  { title: 'Actions', key: 'actions', align: 'end', sortable: false },
];

const filteredOrders = computed(() => {
    if (!searchOrders.value) return serviceStore.serviceOrders;
    const s = searchOrders.value.toLowerCase();
    return serviceStore.serviceOrders.filter(o => 
        o.Customer?.name?.toLowerCase().includes(s) ||
        o.ServiceType?.name?.toLowerCase().includes(s) ||
        o.id.toString().includes(s)
    );
});

const activeServiceTypes = computed(() => 
  serviceStore.serviceTypes.filter(t => t.is_active)
);

/**
 * WORKFLOW & KANBAN LOGIC
 */
/**
 * WORKFLOW & KANBAN LOGIC
 */
const groupedOrders = computed(() => {
  const groups = { Pending: [], InProgress: [], Completed: [], Cancelled: [] };
  serviceStore.serviceOrders.forEach(order => {
    if (groups[order.status]) groups[order.status].push(order);
  });
  return groups;
});

// Data Fetching
const fetchData = async () => {
    await serviceStore.fetchServiceOrders();
    // Also fetch service types for the form
    await serviceStore.fetchServiceTypes({ limit: 1000 });
};

onMounted(fetchData);


/**
 * WORKFLOW ACTIONS
 */
const openOrderForm = () => {
  orderDialog.value = true;
};

const createOrder = async (data) => {
  try {
    await serviceStore.createServiceOrder(data);
    showSnackbar('Service order created successfully');
    orderDialog.value = false;
  } catch (err) {
    showSnackbar(err.message || 'Failed to create order', 'error');
  }
};

const updateStatus = async (order, newStatus) => {
    try {
        if (newStatus === 'Completed') {
            return confirmOrderCompletion(order);
        }
        await serviceStore.updateOrderStatus(order.id, newStatus);
        showSnackbar(`Order ID #${order.id} moved to ${newStatus}`);
    } catch (err) {
        showSnackbar(err.message || 'Failed to update status', 'error');
    }
};

/**
 * COMPLETION WITH AUTO-INVOICE
 */
const confirmOrderCompletion = (order) => {
    selectedOrderForCompletion.value = order;
    confirmDialog.title = 'Complete Service?';
    confirmDialog.message = `This will finalize the service for ${order.Customer?.name} and automatically generate a Draft Invoice for AED ${order.ServiceType?.sell_price}.`;
    confirmDialog.confirmText = 'Complete & Generate Invoice';
    confirmDialog.show = true;
};

const executeOrderCompletion = async () => {
    if (!selectedOrderForCompletion.value) return;
    try {
        const response = await serviceStore.updateOrderStatus(selectedOrderForCompletion.value.id, 'Completed');
        confirmDialog.show = false;
        showSnackbar(response.message || 'Service completed and Draft Invoice generated!', 'success');
        selectedOrderForCompletion.value = null;
    } catch (err) {
        showSnackbar(err.message || 'Failed to complete order', 'error');
    }
};

/**
 * REVERSAL LOGIC
 */
const revertOrder = async (order) => {
    try {
        await serviceStore.updateOrderStatus(order.id, 'InProgress');
        showSnackbar('Service order reverted to In Progress. Associated Draft Invoice was deleted.');
    } catch (err) {
        showSnackbar(err.message || 'Failed to revert order', 'error');
    }
};

const confirmDeleteOrder = async (order) => {
    if (confirm(`Delete Service Order ID #${order.id}?`)) {
        try {
            await serviceStore.deleteServiceOrder(order.id);
            showSnackbar('Order deleted successfully');
        } catch (err) {
            showSnackbar('Failed to delete order', 'error');
        }
    }
};

const getStatusColor = (status) => {
  switch (status) {
    case 'Pending': return 'grey';
    case 'InProgress': return 'primary';
    case 'Completed': return 'success';
    case 'Cancelled': return 'error';
    default: return 'grey';
  }
};

const openWhatsAppRemind = (order) => {
    const num = order.Customer?.phone_whatsapp;
    if (!num) return showSnackbar('Customer phone not found', 'warning');
    
    // We can use a general template or a specific service one
    const msg = `Hi ${order.Customer?.name}, this is a reminder regarding your ${order.ServiceType?.name}. Current status: ${order.status}.`;
    openWhatsApp(num, msg);
};

const formatDate = (dateString) => {
  if (!dateString) return '-';
  const d = new Date(dateString);
  return d.toLocaleDateString('en-GB') + ' ' + d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
};

const showSnackbar = (text, color = 'success') => {
  snackbar.text = text;
  snackbar.color = color;
  snackbar.show = true;
};
</script>

<style scoped>
.kanban-container {
  min-height: 500px;
}
.kanban-row {
  scrollbar-width: thin;
}
.kanban-col {
  min-width: 320px;
  max-width: 400px;
}
.grayscale {
  filter: grayscale(1);
}
.order-card {
  transition: all 0.2s ease-in-out;
  cursor: pointer;
}
.order-card:hover {
  transform: translateY(-4px);
  border-color: rgb(var(--v-theme-primary)) !important;
}
.opacity-60 { opacity: 0.6; }
.opacity-70 { opacity: 0.7; }
.opacity-40 { opacity: 0.4; }
.opacity-50 { opacity: 0.5; }
</style>
