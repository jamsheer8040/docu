<template>
  <v-container fluid v-if="!loading && customer">
    <!-- Header -->
    <v-row class="mb-4">
      <v-col cols="12">
        <v-btn variant="text" prepend-icon="mdi-arrow-left" to="/customers" class="mb-4 font-weight-bold">Back to Customers</v-btn>
        <h1 class="text-h3 font-weight-black text-black">{{ customer.name }}</h1>
        <p class="text-subtitle-1 text-grey-darken-1 font-weight-medium">Customer Profile & History</p>
      </v-col>
    </v-row>

    <!-- Info Cards -->
    <v-row class="mb-6">
      <v-col cols="12" md="4">
        <v-card class="glass-card pa-6 rounded-2xl h-100" variant="flat">
          <div class="d-flex align-center mb-4">
            <v-avatar color="primary" size="64" class="mr-4 rounded-lg">
              <span class="text-h5 text-white font-weight-bold">{{ customer.name.charAt(0).toUpperCase() }}</span>
            </v-avatar>
            <div>
              <div class="text-h6 font-weight-bold">{{ customer.name }}</div>
              <v-chip :color="customer.is_active ? 'success' : 'grey'" size="small" class="mt-1 font-weight-bold text-uppercase text-caption">
                {{ customer.is_active ? 'Active' : 'Inactive' }}
              </v-chip>
            </div>
          </div>
          <v-divider class="mb-4"></v-divider>
          <div class="d-flex align-center mb-3">
             <v-icon icon="mdi-email-outline" color="primary" class="mr-3"></v-icon>
             <span class="font-weight-medium">{{ customer.email || 'N/A' }}</span>
          </div>
          <div class="d-flex align-center mb-3">
             <v-icon icon="mdi-whatsapp" color="success" class="mr-3"></v-icon>
             <span class="font-weight-medium">{{ customer.phone_whatsapp }}</span>
          </div>
          <div class="d-flex align-center mb-3">
             <v-icon icon="mdi-map-marker-outline" color="primary" class="mr-3"></v-icon>
             <span class="font-weight-medium">{{ customer.city || 'N/A' }}, {{ customer.country }}</span>
          </div>
        </v-card>
      </v-col>

      <!-- Stats / Address / TRN -->
      <v-col cols="12" md="8">
        <v-card class="glass-card pa-6 rounded-2xl h-100 d-flex flex-column" variant="flat">
          <h3 class="text-h6 font-weight-bold mb-4">Business Details</h3>
          <v-row>
            <v-col cols="12" sm="6">
              <div class="text-caption font-weight-bold opacity-60 uppercase ls-1 mb-1">Trade License No</div>
              <div class="font-weight-bold text-body-1">{{ customer.trade_license_no || 'N/A' }}</div>
            </v-col>
            <v-col cols="12" sm="6">
               <div class="text-caption font-weight-bold opacity-60 uppercase ls-1 mb-1">Full Address</div>
               <div class="font-weight-medium text-body-1">{{ customer.address || 'N/A' }}</div>
            </v-col>
          </v-row>
          <v-divider class="my-6"></v-divider>
          <div v-if="customer.notes" class="flex-grow-1">
             <div class="text-caption font-weight-bold opacity-60 uppercase ls-1 mb-2">Notes</div>
             <p class="font-weight-medium text-body-2 bg-grey-lighten-4 pa-4 rounded-lg">{{ customer.notes }}</p>
          </div>
          <div v-else class="flex-grow-1 d-flex align-center text-grey text-caption font-weight-medium">
             No specific notes written for this client.
          </div>
        </v-card>
      </v-col>
    </v-row>

    <!-- Tabs for Documents, Services, Invoices -->
    <v-card class="glass-card rounded-2xl" variant="flat">
      <v-tabs v-model="tab" color="primary" class="px-4 pt-2">
        <v-tab value="documents" class="font-weight-bold"><v-icon start icon="mdi-file-document-outline"></v-icon> Documents</v-tab>
        <v-tab value="services" class="font-weight-bold"><v-icon start icon="mdi-briefcase-outline"></v-icon> Services</v-tab>
        <v-tab value="invoices" class="font-weight-bold"><v-icon start icon="mdi-receipt"></v-icon> Invoices</v-tab>
      </v-tabs>
      <v-divider></v-divider>
      
      <v-window v-model="tab">
        <v-window-item value="documents">
          <v-data-table
            :headers="docHeaders"
            :items="customer.Documents"
            class="pa-4 bg-transparent"
          >
             <template v-slot:item.doc_type_display="{ item }">
               <v-chip
                 :color="item.DocumentType ? 'primary' : 'grey-darken-1'"
                 size="small"
                 label
                 class="font-weight-bold"
                 variant="flat"
               >
                 {{ item.DocumentType?.name || item.type || 'General' }}
               </v-chip>
             </template>
             <template v-slot:item.expiry_date="{ item }">
               <span class="font-weight-medium">{{ formatDate(item.expiry_date) }}</span>
             </template>
             <template v-slot:item.actions="{ item }">
                <v-btn 
                  v-if="item.file_path" 
                  prepend-icon="mdi-eye" 
                  variant="outlined" 
                  color="primary" 
                  size="small" 
                  class="font-weight-bold border"
                  @click="openDocumentPreview(item.file_path)"
                >View</v-btn>
             </template>
          </v-data-table>
        </v-window-item>
        
        <v-window-item value="services">
          <v-data-table
            :headers="serviceHeaders"
            :items="customer.ServiceOrders"
            class="pa-4 bg-transparent"
          >
            <template v-slot:item.created_at="{ item }">
               <span class="font-weight-medium">{{ formatDate(item.created_at) }}</span>
            </template>
            <template v-slot:item.service="{ item }">
               <span class="font-weight-bold">{{ item.ServiceType?.name }}</span>
            </template>
            <template v-slot:item.total_price="{ item }">
               <span class="font-weight-medium">AED {{ parseFloat(item.ServiceType?.sell_price || 0).toFixed(2) }}</span>
            </template>
            <template v-slot:item.status="{ item }">
                <v-chip size="x-small" :color="getServiceColor(item.status)" class="font-weight-bold text-uppercase">{{ item.status }}</v-chip>
            </template>
          </v-data-table>
        </v-window-item>

        <v-window-item value="invoices">
          <v-data-table
            :headers="invoiceHeaders"
            :items="customer.Invoices"
            class="pa-4 bg-transparent"
          >
            <template v-slot:item.created_at="{ item }">
               <span class="font-weight-medium">{{ formatDate(item.created_at) }}</span>
            </template>
            <template v-slot:item.invoice_number="{ item }">
               <span class="font-weight-bold text-primary">{{ item.invoice_number }}</span>
            </template>
            <template v-slot:item.total="{ item }">
               <span class="font-weight-medium">AED {{ parseFloat(item.total).toFixed(2) }}</span>
            </template>
            <template v-slot:item.pending_amount="{ item }">
               <span class="font-weight-bold" :class="(parseFloat(item.total) - parseFloat(item.paid_amount || 0)) > 0 ? 'text-error' : 'text-success'">
                 AED {{ (parseFloat(item.total) - parseFloat(item.paid_amount || 0)).toFixed(2) }}
               </span>
            </template>
            <template v-slot:item.status="{ item }">
                <v-chip size="x-small" :color="getInvoiceColor(item.status)" class="font-weight-bold text-uppercase">{{ item.status }}</v-chip>
            </template>
            <template v-slot:item.actions="{ item }">
               <div class="d-flex justify-end pt-1">
                 <v-btn icon="mdi-eye-outline" variant="text" size="small" color="primary" @click="viewInvoice(item)" title="View Invoice"></v-btn>
               </div>
            </template>
          </v-data-table>
        </v-window-item>
      </v-window>
    </v-card>

    <!-- Document Viewer Dialog -->
    <v-dialog v-model="previewDialog" max-width="900" fullscreen-on-mobile>
      <v-card class="rounded-xl overflow-hidden glass-card" variant="flat">
        <v-toolbar color="transparent" title="Document Preview">
          <template v-slot:append>
             <v-btn icon="mdi-share-variant" variant="text" @click="shareDocument(previewUrl)" title="Share Document Link"></v-btn>
             <v-btn icon="mdi-open-in-new" variant="text" :href="previewUrl" target="_blank" title="Open PDF / Image in new tab"></v-btn>
             <v-btn icon="mdi-close" @click="previewDialog = false" variant="text"></v-btn>
          </template>
        </v-toolbar>
        <v-divider></v-divider>
        <v-card-text class="pa-0 bg-grey-lighten-4 d-flex align-center justify-center p-relative" style="min-height: 500px;">
            <iframe 
              v-if="previewUrl && previewUrl.toLowerCase().endsWith('.pdf')" 
              :src="previewUrl" 
              style="width: 100%; height: 75vh; border: none; display: block;"
            ></iframe>
            <img 
              v-else-if="previewUrl"
              :src="previewUrl" 
              style="max-width: 100%; max-height: 75vh; object-fit: contain; display: block;" 
            />
            <div v-else class="text-h6 text-grey font-weight-medium">Preview not available</div>
        </v-card-text>
      </v-card>
    </v-dialog>
    
    <!-- Invoice Preview Dialog -->
    <v-dialog v-model="viewInvoiceDialog" max-width="900px">
        <InvoiceDetailView 
            v-if="viewInvoiceDialog" 
            :invoice-id="selectedInvoiceId" 
            @close="viewInvoiceDialog = false" 
        />
    </v-dialog>

  </v-container>
  
  <div v-else-if="loading" class="d-flex justify-center align-center h-100 pt-16">
    <v-progress-circular indeterminate color="primary" size="64" width="6"></v-progress-circular>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { useNuxtApp, useRuntimeConfig } from '#app';
import { useUIStore } from '@/stores/ui';
import { useInvoiceStore } from '@/stores/invoices';
import InvoiceDetailView from '~/components/invoices/InvoiceDetailView.vue';
import dayjs from 'dayjs';

const route = useRoute();
const { $api } = useNuxtApp();
const config = useRuntimeConfig();
const uiStore = useUIStore();
const invoiceStore = useInvoiceStore();

const customer = ref(null);
const loading = ref(true);
const tab = ref('documents');

const previewDialog = ref(false);
const previewUrl = ref('');
const viewInvoiceDialog = ref(false);
const selectedInvoiceId = ref(null);

const docHeaders = [
  { title: 'Document Type', key: 'doc_type_display', sortable: true },
  { title: 'Doc Number', key: 'doc_number', sortable: false },
  { title: 'Expiry Date', key: 'expiry_date', sortable: true },
  { title: 'Actions', key: 'actions', sortable: false, align: 'end' }
];

const serviceHeaders = [
  { title: 'Date', key: 'created_at', sortable: true },
  { title: 'Service Name', key: 'service', sortable: true },
  { title: 'Status', key: 'status', sortable: true },
  { title: 'Total Amount', key: 'total_price', sortable: false }
];

const invoiceHeaders = [
  { title: 'Invoice Date', key: 'created_at', sortable: true },
  { title: 'Invoice No.', key: 'invoice_number', sortable: true },
  { title: 'Total Amount', key: 'total', sortable: false },
  { title: 'Pending Amount', key: 'pending_amount', sortable: false },
  { title: 'Status', key: 'status', sortable: true },
  { title: 'Actions', key: 'actions', sortable: false, align: 'end' }
];

const fetchCustomer = async () => {
  try {
    const res = await $api.get(`/customers/${route.params.id}`);
    if (res.data.success) {
      customer.value = res.data.data;
    }
  } catch (err) {
    console.error('Failed to load customer details', err);
  } finally {
    loading.value = false;
  }
};

const formatDate = (dateString) => {
  if (!dateString) return '';
  return dayjs(dateString).format('DD/MM/YYYY');
};

const getServiceColor = (status) => {
  switch (status) {
    case 'Pending': return 'warning';
    case 'In Progress': return 'primary';
    case 'Completed': return 'success';
    case 'Cancelled': return 'error';
    default: return 'grey';
  }
};

const getInvoiceColor = (status) => {
  switch (status) {
    case 'Draft': return 'grey';
    case 'Sent': return 'primary';
    case 'Partially Paid': return 'info';
    case 'Paid': return 'success';
    case 'Overdue': return 'error';
    case 'Cancelled': return 'warning';
    default: return 'grey';
  }
};

const openDocumentPreview = (filePath) => {
  if (!filePath) return;
  const baseUrl = config.public.apiBase.replace('/api/v1', '');
  previewUrl.value = baseUrl + filePath;
  previewDialog.value = true;
};

const shareDocument = async (url) => {
  try {
    if (navigator.share) {
      await navigator.share({
        title: 'Document Shared via DocClear',
        url: url
      });
    } else {
      await navigator.clipboard.writeText(url);
      uiStore.showSuccess('Document link copied to clipboard!');
    }
  } catch (err) {
    if (err.name !== 'AbortError') {
      uiStore.showError('Failed to share document');
    }
  }
};

const viewInvoice = (invoice) => {
  selectedInvoiceId.value = invoice.id;
  viewInvoiceDialog.value = true;
};

onMounted(() => {
  fetchCustomer();
});
</script>

<style scoped>
/* Keep the deep soft UI consistent */
</style>
