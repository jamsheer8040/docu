<template>
  <v-container fluid class="pa-6">
    <!-- Header -->
    <v-row class="mb-4 align-center">
      <v-col cols="12" md="6">
        <h1 class="text-h4 font-weight-bold color-primary">
          <v-icon icon="mdi-file-eye-outline" class="mr-2" color="primary"></v-icon>
          Document Tracker
        </h1>
        <p class="text-subtitle-1 text-grey-darken-1">Monitor and manage document validity across your client base</p>
      </v-col>
      <v-col cols="12" md="6" class="d-flex align-center justify-md-end flex-wrap" style="gap: 16px;">
        <v-btn-toggle
          v-model="viewMode"
          mandatory
          variant="text"
          class="d-flex"
          style="gap: 8px;"
        >
          <v-btn
            value="kanban"
            rounded="lg"
            :variant="viewMode === 'kanban' ? 'flat' : 'outlined'"
            color="primary"
            class="px-6 font-weight-bold border"
            prepend-icon="mdi-view-column"
          >
            Kanban
          </v-btn>
          <v-btn
            value="list"
            rounded="lg"
            :variant="viewMode === 'list' ? 'flat' : 'outlined'"
            color="primary"
            class="px-6 font-weight-bold border"
            prepend-icon="mdi-format-list-bulleted"
          >
            List
          </v-btn>
          <v-btn
            value="calendar"
            rounded="lg"
            :variant="viewMode === 'calendar' ? 'flat' : 'outlined'"
            color="primary"
            class="px-4 px-md-6 font-weight-bold border"
            prepend-icon="mdi-calendar-month"
          >
            Calendar
          </v-btn>
        </v-btn-toggle>
      </v-col>
    </v-row>

    <!-- Status / Errors -->
    <v-row v-if="error" class="mb-4">
      <v-col cols="12">
        <v-alert
          type="error"
          variant="tonal"
          closable
          icon="mdi-alert-circle-outline"
          class="rounded-xl"
        >
          {{ error }}
          <template v-slot:append>
             <v-btn variant="text" size="small" @click="fetchDocuments">Retry</v-btn>
          </template>
        </v-alert>
      </v-col>
    </v-row>

    <!-- Action Bar -->
    <v-row class="mb-6 align-center">
      <v-col cols="12" sm="6" md="3">
        <v-select
          v-model="urgencyFilter"
          :items="[
            { title: 'All Documents', value: 'all' },
            { title: 'Expired', value: 'expired' },
            { title: 'Critical (0-7 Days)', value: 'critical' },
            { title: 'Warning (7-14 Days)', value: 'warning' },
            { title: 'Due Soon (14-30 Days)', value: 'due_soon' },
            { title: 'Active (>30 Days)', value: 'active' }
          ]"
          label="Filter by Status"
          prepend-inner-icon="mdi-filter-variant"
          variant="outlined"
          rounded="lg"
          bg-color="white"
          hide-details
          class="font-weight-bold"
          density="compact"
        >
          <template v-slot:item="{ props, item }">
            <v-list-item v-bind="props">
               <template v-slot:prepend>
                  <v-icon 
                    :icon="getStatusIcon(item.value)" 
                    :color="getStatusColor(item.value)"
                  ></v-icon>
               </template>
            </v-list-item>
          </template>
        </v-select>
      </v-col>
      <v-col cols="12" sm="6" md="6">
        <v-text-field
          v-model="searchQuery"
          label="Search documents..."
          prepend-inner-icon="mdi-magnify"
          bg-color="white"
          variant="outlined"
          hide-details
          rounded="lg"
          density="compact"
        ></v-text-field>
      </v-col>
      <v-col cols="12" md="3" class="d-flex justify-md-end">
        <v-btn
          v-if="auth.can('documents', 'write')"
          color="primary"
          prepend-icon="mdi-plus"
          rounded="lg"
          elevation="2"
          height="40"
          block
          class="font-weight-bold"
          @click="openForm()"
        >
          Add Document
        </v-btn>
      </v-col>
    </v-row>

    <!-- Unified View Container (No unmounting on load) -->
    <div class="views-container">
      <!-- Kanban View -->
      <div v-if="viewMode === 'kanban'" class="kanban-wrapper">
         <v-row v-if="loading && !allDocumentsFlat.length" class="mt-4">
          <v-col v-for="i in 4" :key="i" cols="12" md="3">
            <v-skeleton-loader type="card" height="300"></v-skeleton-loader>
          </v-col>
        </v-row>
        <v-row v-else class="kanban-row">
        <!-- Expired Column -->
        <v-col v-if="urgencyFilter === 'all' || urgencyFilter === 'expired'" class="kanban-col">
          <div class="pa-2 mb-2">
            <v-chip color="error" variant="tonal" class="font-weight-bold px-4 py-4" style="height: auto; width: 100%; border-radius: 12px;">
              <v-icon start icon="mdi-alert-circle"></v-icon>
              Expired ({{ documentStore.groupedDocs.expired.length }})
            </v-chip>
          </div>
          <div class="col-content pa-2 rounded-xl">
            <DocumentCard
              v-for="doc in filterDocs(documentStore.groupedDocs.expired)"
              :key="doc.id"
              :document="doc"
              @edit="openForm"
              @delete="confirmDelete"
            />
            <div v-if="documentStore.groupedDocs.expired.length === 0" class="text-caption text-center py-4 text-grey">No expired documents</div>
          </div>
        </v-col>

        <!-- Critical (Within 1 Week) -->
        <v-col v-if="urgencyFilter === 'all' || urgencyFilter === 'critical'" class="kanban-col">
          <div class="pa-2 mb-2">
            <v-chip color="error" variant="flat" class="font-weight-bold px-4 py-4" style="height: auto; width: 100%; border-radius: 12px;">
              <v-icon start icon="mdi-clock-alert"></v-icon>
              Within 1 Week ({{ documentStore.groupedDocs.critical.length }})
            </v-chip>
          </div>
          <div class="col-content pa-2 rounded-xl">
            <DocumentCard
              v-for="doc in filterDocs(documentStore.groupedDocs.critical)"
              :key="doc.id"
              :document="doc"
              @edit="openForm"
              @delete="confirmDelete"
            />
            <div v-if="documentStore.groupedDocs.critical.length === 0" class="text-caption text-center py-4 text-grey">No critical documents</div>
          </div>
        </v-col>

        <!-- Warning (Within 2 Weeks) -->
        <v-col v-if="urgencyFilter === 'all' || urgencyFilter === 'warning'" class="kanban-col">
          <div class="pa-2 mb-2">
            <v-chip color="warning" variant="tonal" class="font-weight-bold px-4 py-4" style="height: auto; width: 100%; border-radius: 12px;">
              <v-icon start icon="mdi-bell-ring"></v-icon>
              Within 2 Weeks ({{ documentStore.groupedDocs.warning.length }})
            </v-chip>
          </div>
          <div class="col-content pa-2 rounded-xl">
            <DocumentCard
              v-for="doc in filterDocs(documentStore.groupedDocs.warning)"
              :key="doc.id"
              :document="doc"
              @edit="openForm"
              @delete="confirmDelete"
            />
            <div v-if="documentStore.groupedDocs.warning.length === 0" class="text-caption text-center py-4 text-grey">No warnings</div>
          </div>
        </v-col>

        <!-- Month (Within 1 Month) -->
        <v-col v-if="urgencyFilter === 'all' || urgencyFilter === 'due_soon'" class="kanban-col">
          <div class="pa-2 mb-2">
            <v-chip color="info" variant="tonal" class="font-weight-bold px-4 py-4" style="height: auto; width: 100%; border-radius: 12px;">
              <v-icon start icon="mdi-calendar-clock"></v-icon>
              Within 1 Month ({{ documentStore.groupedDocs.month.length }})
            </v-chip>
          </div>
          <div class="col-content pa-2 rounded-xl">
            <DocumentCard
              v-for="doc in filterDocs(documentStore.groupedDocs.month)"
              :key="doc.id"
              :document="doc"
              @edit="openForm"
              @delete="confirmDelete"
            />
            <div v-if="documentStore.groupedDocs.month.length === 0" class="text-caption text-center py-4 text-grey">No upcoming expiries</div>
          </div>
        </v-col>

        <!-- Safe -->
        <v-col v-if="urgencyFilter === 'all' || urgencyFilter === 'active'" class="kanban-col">
          <div class="pa-2 mb-2">
            <v-chip color="success" variant="tonal" class="font-weight-bold px-4 py-4" style="height: auto; width: 100%; border-radius: 12px;">
              <v-icon start icon="mdi-check-circle"></v-icon>
              Safe ({{ documentStore.groupedDocs.safe.length }})
            </v-chip>
          </div>
          <div class="col-content pa-2 rounded-xl">
            <DocumentCard
              v-for="doc in filterDocs(documentStore.groupedDocs.safe)"
              :key="doc.id"
              :document="doc"
              @edit="openForm"
              @delete="confirmDelete"
            />
            <div v-if="documentStore.groupedDocs.safe.length === 0" class="text-caption text-center py-4 text-grey">No safe documents</div>
          </div>
        </v-col>
      </v-row>
    </div>

    <!-- List View -->
    <div v-if="viewMode === 'list'" class="list-container">
      <v-card class="border" border>
        <v-data-table-server
          v-model:items-per-page="itemsPerPage"
          :headers="headers"
          :items="documentStore.documents"
          :items-length="documentStore.totalDocuments"
          :loading="documentStore.loading"
          @update:options="loadDocumentList"
          hover
        >
          <template v-slot:item.Customer="{ item }">
            <div class="font-weight-bold">{{ item.Customer?.name }}</div>
          </template>
          
          <template v-slot:item.status="{ item }">
            <v-chip :color="getUrgencyColor(item.expiry_date)" size="x-small" label class="font-weight-black text-uppercase">
               {{ getStatusLabel(item.expiry_date) }}
            </v-chip>
          </template>

          <template v-slot:item.type="{ item }">
            <span class="font-weight-bold">{{ item.DocumentType?.name || item.type }}</span>
          </template>

          <template v-slot:item.expiry_date="{ item }">
            <span class="text-caption font-weight-bold">{{ formatDate(item.expiry_date) }}</span>
          </template>

          <template v-slot:item.actions="{ item }">
            <v-btn 
              v-if="item.file_path" 
              icon="mdi-eye-outline" 
              variant="text" 
              size="small" 
              color="info" 
              title="View Document"
              @click="openDocumentPreview(item.file_path)"
            ></v-btn>
            <v-btn v-if="auth.can('documents', 'write')" icon="mdi-pencil" variant="text" size="small" color="primary" @click="openForm(item)"></v-btn>
            <v-btn v-if="auth.can('documents', 'delete')" icon="mdi-delete" variant="text" size="small" color="error" @click="confirmDelete(item)"></v-btn>
          </template>
        </v-data-table-server>
      </v-card>
    </div>

    <!-- Calendar View -->
    <div v-if="viewMode === 'calendar'" class="calendar-container">
      <v-card class="pa-6 border" border>
        <div class="d-flex align-center justify-space-between mb-4">
          <v-btn icon="mdi-chevron-left" variant="text" @click="prevMonth"></v-btn>
          <h2 class="text-h5">{{ currentMonthName }} {{ currentYear }}</h2>
          <v-btn icon="mdi-chevron-right" variant="text" @click="nextMonth"></v-btn>
        </div>

        <div class="calendar-grid">
          <div v-for="day in weekDays" :key="day" class="calendar-header-cell">
            {{ day }}
          </div>
          <div
            v-for="(cell, index) in calendarCells"
            :key="index"
            class="calendar-day-cell"
            :class="{ 'other-month': cell.otherMonth, 'is-today': cell.isToday }"
          >
            <div class="day-number">{{ cell.date.date() }}</div>
            <div class="day-dot-container">
               <template v-for="doc in getDocsForDate(cell.date)" :key="doc.id">
                 <v-tooltip location="top">
                    <template v-slot:activator="{ props }">
                      <v-chip
                        v-bind="props"
                        :color="getUrgencyColor(doc.expiry_date)"
                        size="x-small"
                        class="mb-1 d-block text-truncate"
                        @click="openDetails(doc)"
                      >
                        {{ doc.DocumentType?.name || doc.type }}: {{ doc.Customer?.name }}
                      </v-chip>
                    </template>
                    <span>{{ doc.DocumentType?.name || doc.type }} - {{ doc.Customer?.name }} ({{ doc.doc_number }})</span>
                 </v-tooltip>
               </template>
            </div>
          </div>
        </div>
      </v-card>
    </div>
  </div>

    <!-- Form Dialog -->
    <v-dialog v-model="formDialog" max-width="800px" persistent>
      <DocumentForm
        v-if="formDialog"
        :document="activeDocument"
        :loading="saving"
        @save="saveDocument"
        @cancel="closeForm"
      />
    </v-dialog>

    <!-- Delete Confirm -->
    <v-dialog v-model="deleteDialog" max-width="400px">
      <v-card>
        <v-card-title class="text-h5">Confirm Delete</v-card-title>
        <v-card-text>Are you sure you want to delete this document record? This action cannot be undone.</v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn variant="text" @click="deleteDialog = false">Cancel</v-btn>
          <v-btn color="error" variant="flat" @click="executeDelete" :loading="deleting">Delete</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Details Popover/Dialog (for Calendar) -->
     <v-dialog v-model="detailsDialog" max-width="500px">
        <v-card v-if="selectedDoc">
          <v-card-title class="bg-primary text-white">
            {{ selectedDoc.DocumentType?.name || selectedDoc.type }} Details
          </v-card-title>
          <v-card-text class="pt-4">
            <div class="mb-2"><strong>Customer:</strong> {{ selectedDoc.Customer?.name }}</div>
            <div class="mb-2"><strong>Doc Number:</strong> {{ selectedDoc.doc_number || 'N/A' }}</div>
            <div class="mb-2"><strong>Expiry Date:</strong> {{ formatDate(selectedDoc.expiry_date) }}</div>
            <div class="mb-2"><strong>Issue Date:</strong> {{ formatDate(selectedDoc.issue_date) || 'N/A' }}</div>
            <div class="mb-2" v-if="selectedDoc.notes"><strong>Notes:</strong> {{ selectedDoc.notes }}</div>
          </v-card-text>
          <v-divider></v-divider>
          <v-card-actions>
            <v-btn 
              v-if="selectedDoc.Customer?.phone_whatsapp"
              color="success" 
              prepend-icon="mdi-whatsapp"
              @click="sendWhatsAppReminder(selectedDoc)"
            >
              WhatsApp
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn variant="text" @click="detailsDialog = false">Close</v-btn>
            <v-btn color="primary" variant="outlined" @click="editFromDetails(selectedDoc)">Edit</v-btn>
          </v-card-actions>
        </v-card>
     </v-dialog>

    <!-- Document Viewer Dialog -->
    <v-dialog v-model="previewDialog" max-width="900" fullscreen-on-mobile>
      <v-card class="rounded-xl overflow-hidden glass-card" variant="flat">
        <v-toolbar color="transparent" title="Document Preview">
          <template v-slot:append>
             <v-btn icon="mdi-share-variant" variant="text" @click="shareDocument(previewUrl)" title="Share Document Link"></v-btn>
             <v-btn icon="mdi-open-in-new" variant="text" :href="previewUrl" target="_blank" title="Open PDF / Image in new tab"></v-btn>
             <v-btn icon="mdi-close" @click="previewDialog = false" variant="text"></v-btn>
          </template>
        </v-toolbar>
        <v-divider></v-divider>
        <v-card-text class="pa-0 bg-grey-lighten-4 d-flex align-center justify-center p-relative" style="min-height: 500px;">
            <iframe 
              v-if="previewUrl && previewUrl.toLowerCase().endsWith('.pdf')" 
              :src="previewUrl" 
              style="width: 100%; height: 75vh; border: none; display: block;"
            ></iframe>
            <img 
              v-else-if="previewUrl"
              :src="previewUrl" 
              style="max-width: 100%; max-height: 75vh; object-fit: contain; display: block;" 
            />
            <div v-else class="text-h6 text-grey font-weight-medium">Preview not available</div>
        </v-card-text>
      </v-card>
    </v-dialog>

  </v-container>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue';
import dayjs from 'dayjs';
import DocumentCard from '~/components/documents/DocumentCard.vue';
import DocumentForm from '~/components/documents/DocumentForm.vue';
import { useWhatsApp } from '~/composables/useWhatsApp';
import { useAuthStore } from '~/stores/auth';
import { useDocumentStore } from '~/stores/documents';
import { useUIStore } from '~/stores/ui';

// State
const auth = useAuthStore();
const documentStore = useDocumentStore();
const uiStore = useUIStore();
const config = useRuntimeConfig();
const viewMode = ref('kanban'); // kanban, list, calendar
const searchQuery = ref('');
const urgencyFilter = ref('all');
const itemsPerPage = ref(10);
const currentPage = ref(1);
const loading = computed(() => documentStore.loading);
const error = computed(() => documentStore.error);

// Dialogs
const formDialog = ref(false);
const activeDocument = ref(null);
const saving = ref(false);

const deleteDialog = ref(false);
const docToDelete = ref(null);
const deleting = ref(false);

const detailsDialog = ref(false);
const selectedDoc = ref(null);

const previewDialog = ref(false);
const previewUrl = ref('');

// Constants
const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const { openWhatsApp, MESSAGES } = useWhatsApp();

const headers = [
  { title: 'Customer', key: 'Customer', sortable: true },
  { title: 'Document Type', key: 'type', sortable: true },
  { title: 'Doc Number', key: 'doc_number', sortable: true },
  { title: 'Status', key: 'status', sortable: false },
  { title: 'Expiry Date', key: 'expiry_date', sortable: true },
  { title: 'Actions', key: 'actions', sortable: false, align: 'end' }
];

// Calculated properties for Kanban/Calendar
const allDocumentsFlat = computed(() => [
  ...documentStore.groupedDocs.expired,
  ...documentStore.groupedDocs.critical,
  ...documentStore.groupedDocs.warning,
  ...documentStore.groupedDocs.month,
  ...documentStore.groupedDocs.safe
]);

// Calendar State
const calendarDate = ref(dayjs());
const currentMonthName = computed(() => calendarDate.value.format('MMMM'));
const currentYear = computed(() => calendarDate.value.format('YYYY'));

const calendarCells = computed(() => {
  const startOfMonth = calendarDate.value.startOf('month');
  const endOfMonth = calendarDate.value.endOf('month');
  const startDate = startOfMonth.startOf('week');
  const endDate = endOfMonth.endOf('week');

  const cells = [];
  let day = startDate;

  while (day.isBefore(endDate) || day.isSame(endDate, 'day')) {
    cells.push({
      date: day,
      isToday: day.isSame(dayjs(), 'day'),
      otherMonth: !day.isSame(calendarDate.value, 'month')
    });
    day = day.add(1, 'day');
  }
  return cells;
});

// Methods
const fetchDocuments = async () => {
    await documentStore.fetchExpiring();
};

const loadDocumentList = async ({ page, itemsPerPage: limit }) => {
    currentPage.value = page;
    itemsPerPage.value = limit;
    
    await documentStore.fetchDocuments({
        page,
        limit,
        search: searchQuery.value || undefined,
        expiry_status: urgencyFilter.value !== 'all' ? urgencyFilter.value : undefined
    });
};

const filterDocs = (docs) => {
  if (!searchQuery.value) return docs;
  const q = searchQuery.value.toLowerCase();
  return docs.filter(d => 
    d.Customer?.name.toLowerCase().includes(q) || 
    (d.doc_number && d.doc_number.toLowerCase().includes(q)) ||
    (d.DocumentType?.name || d.type).toLowerCase().includes(q)
  );
};

const getDocsForDate = (date) => {
  const dateStr = date.format('YYYY-MM-DD');
  return allDocumentsFlat.value.filter(d => d.expiry_date === dateStr);
};

const getUrgencyColor = (expiryDate) => {
  const diff = dayjs(expiryDate).diff(dayjs().startOf('day'), 'day');
  if (diff < 0) return 'error';
  if (diff <= 7) return 'error';
  if (diff <= 14) return 'warning';
  if (diff <= 30) return 'info';
  return 'success';
};

const getStatusLabel = (expiryDate) => {
  const diff = dayjs(expiryDate).diff(dayjs().startOf('day'), 'day');
  if (diff < 0) return 'Expired';
  if (diff <= 7) return 'Critical';
  if (diff <= 14) return 'Warning';
  if (diff <= 30) return 'Due Soon';
  return 'Active';
};

const getStatusIcon = (status) => {
  switch (status) {
    case 'expired': return 'mdi-alert-circle';
    case 'critical': return 'mdi-clock-alert';
    case 'warning': return 'mdi-bell-ring';
    case 'due_soon': return 'mdi-calendar-clock';
    case 'active': return 'mdi-check-circle';
    default: return 'mdi-filter-variant';
  }
};

const getStatusColor = (status) => {
  switch (status) {
    case 'expired': case 'critical': return 'error';
    case 'warning': return 'warning';
    case 'due_soon': return 'info';
    case 'active': return 'success';
    default: return 'primary';
  }
};

// Form Actions
const openForm = (doc = null) => {
  activeDocument.value = doc;
  formDialog.value = true;
};

const closeForm = () => {
  formDialog.value = false;
  activeDocument.value = null;
};

const saveDocument = async (formData) => {
  saving.value = true;
  try {
    if (activeDocument.value) {
      await documentStore.updateDocument(activeDocument.value.id, formData);
    } else {
      await documentStore.createDocument(formData);
    }
    
    fetchDocuments(); // Update Kanban
    loadDocumentList({ page: currentPage.value, itemsPerPage: itemsPerPage.value }); // Update List
    closeForm();
  } catch (err) {
    console.error('Failed to save document', err);
  } finally {
    saving.value = false;
  }
};

// Delete Actions
const confirmDelete = (doc) => {
  docToDelete.value = doc;
  deleteDialog.value = true;
};

const executeDelete = async () => {
  if (!docToDelete.value) return;
  deleting.value = true;
  try {
    await documentStore.deleteDocument(docToDelete.value.id);
    fetchDocuments();
    loadDocumentList({ page: currentPage.value, itemsPerPage: itemsPerPage.value });
    deleteDialog.value = false;
    docToDelete.value = null;
  } catch (err) {
    console.error('Failed to delete document', err);
  } finally {
    deleting.value = false;
  }
};

// Calendar Nav
const prevMonth = () => { calendarDate.value = calendarDate.value.subtract(1, 'month'); };
const nextMonth = () => { calendarDate.value = calendarDate.value.add(1, 'month'); };

// Details
const openDetails = (doc) => {
  selectedDoc.value = doc;
  detailsDialog.value = true;
};

const editFromDetails = (doc) => {
  detailsDialog.value = false;
  openForm(doc);
};

const openDocumentPreview = (filePath) => {
  if (!filePath) return;
  const baseUrl = config.public.apiBase.replace('/api/v1', '');
  previewUrl.value = baseUrl + filePath;
  previewDialog.value = true;
};

const shareDocument = async (url) => {
  try {
    if (navigator.share) {
      await navigator.share({
        title: 'Document Shared via DocClear',
        url: url
      });
    } else {
      await navigator.clipboard.writeText(url);
      uiStore.showSuccess('Document link copied to clipboard!');
    }
  } catch (err) {
    if (err.name !== 'AbortError') {
      uiStore.showError('Failed to share document');
    }
  }
};

const sendWhatsAppReminder = (doc) => {
  const num = doc.Customer.phone_whatsapp;
  const msg = MESSAGES.docReminder(
    doc.Customer.name,
    doc.DocumentType?.name || doc.type,
    doc.doc_number || 'N/A',
    formatDate(doc.expiry_date)
  );
  openWhatsApp(num, msg);
};

const formatDate = (dateString) => {
  if (!dateString) return '';
  return dayjs(dateString).format('DD/MM/YYYY');
};

onMounted(() => {
  fetchDocuments();
});

let searchTimer;
watch(searchQuery, () => {
    if (viewMode.value === 'list') {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(() => {
            loadDocumentList({ page: 1, itemsPerPage: itemsPerPage.value });
        }, 400);
    }
});

watch(urgencyFilter, () => {
    if (viewMode.value === 'list') {
        loadDocumentList({ page: 1, itemsPerPage: itemsPerPage.value });
    }
});
</script>

<style scoped>
.kanban-wrapper {
  overflow-x: auto;
  padding-bottom: 20px;
}

.kanban-row {
  display: flex;
  flex-wrap: nowrap;
  min-width: 1200px;
}

.kanban-col {
  flex: 1;
  min-width: 280px;
  max-width: 320px;
  display: flex;
  flex-direction: column;
}

.col-content {
  flex-grow: 1;
  min-height: 500px;
  overflow-y: auto;
}

/* Calendar Styles */
.calendar-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  border: 1px solid #e0e0e0;
}

.calendar-header-cell {
  background-color: rgb(var(--v-theme-surface-variant));
  color: rgb(var(--v-theme-on-surface-variant));
  padding: 10px;
  text-align: center;
  font-weight: bold;
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
  border-right: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.calendar-day-cell {
  min-height: 120px;
  padding: 8px;
  border-bottom: 1px solid #e0e0e0;
  border-right: 1px solid #e0e0e0;
  position: relative;
}

.calendar-day-cell.other-month {
  background-color: #fafafa;
  color: #bdbdbd;
}

.calendar-day-cell.is-today {
  background-color: rgb(var(--v-theme-primary-container));
  color: rgb(var(--v-theme-on-primary-container));
}

.day-number {
  font-weight: bold;
  margin-bottom: 5px;
}

.day-dot-container {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
</style>
